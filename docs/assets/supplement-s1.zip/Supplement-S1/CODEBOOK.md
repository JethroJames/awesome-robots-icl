# Reference census and mechanism coding

**unit.** One numbered reference in the current manuscript. Distinct citations of a paper and its dataset release count as distinct references.

**scope.** All 616 actively cited bibliography entries contribute to annual counts. The method panel includes all references that contribute a control mechanism identifiable within the four families, including memory, contextual corrections, pretrained action models and parameter-adaptation comparisons.

**method_families.** {"policy": "Context-conditioned policies", "geometry": "Geometric demonstration transfer", "world": "World-model-based control", "agent": "Skill- and agent-based execution"}

**other_document_roles.** {"data": "Data resources", "evaluation": "Evaluation", "foundations": "Foundations and surveys", "training": "Training and representations"}

**primary_family.** Code the deployed path from context to robot behavior: infer actions; transfer an explicit demonstration reference; predict outcomes before decoding or planning; or produce skills, programs and tool calls for an executor. In mixed systems, distinguish runtime prediction from world-model-generated training data.

**independent_axes.** Parameter updates, memory storage, data scale and instruction modality remain independent of family. A family assignment does not by itself establish fixed-weight ICL.

**denominators.** {"annual": 616, "methods": 392}

**date.** First public year from arXiv v1 or official publications and releases; chart groups years through 2015 and marks 2026 as partial through 12 November.

**as_of.** 2026-11-12
