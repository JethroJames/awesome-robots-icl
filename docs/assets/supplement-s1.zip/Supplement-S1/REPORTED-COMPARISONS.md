# Reported comparisons

Source-specific comparisons quoted in the manuscript. Conditions differ across studies and are retained in each entry.

## ICRT

DROID subset versus multi-task training. DROID-only variant makes no progress on test tasks Training sets differ; held-out tasks use known motion primitives and new objects

[Primary source](https://arxiv.org/html/2408.15980v2), Sec. VI-B; Sec. III; Table II. Checked 2026-09-21.

## BPP

Behavior prompt versus matched goal image. Demonstration prompting improves qualitative fidelity on unseen drawings Same canvas and initial state; a video supplies path information absent from an endpoint; Chamfer distance alone can conceal poor shape fidelity

[Primary source](https://arxiv.org/html/2606.30457v1), Sec. 4.2; Appendix B.2; Figure 9. Checked 2026-09-21.

## LMAct

Zero to 512 expert episodes. More examples often have little effect; some task/model combinations improve General-purpose models in interactive tasks including simulated cheetah, not a real manipulation benchmark

[Primary source](https://proceedings.mlr.press/v267/ruoss25a.html), Abstract and evaluation summary. Checked 2026-09-21.

## Show-Harness

Semantic or arbitrary action names crossed with written conventions present or absent. Arbitrary names without conventions yield 1/20 successful episodes and 23.3% correct mappings Same remaining harness; Gemini 3.1 Pro; tests unfamiliar action grounding rather than general video following

[Primary source](https://arxiv.org/html/2609.10522v1), Sec. 5.4; Figure 10. Checked 2026-09-21.

## MT3

Retrieval versus behavioral cloning; phase decomposition versus monolithic policy. MT3 at three demonstrations/task outperforms tested alternatives at 50 demonstrations/task in controlled comparison Alignment followed by interaction; seen and unseen object instances; scope of open-loop interaction is analyzed separately

[Primary source](https://arxiv.org/html/2511.10110v1), Sec. 2.3.1; Figure 4; Sec. 2.4.4. Checked 2026-09-21.

## Part-based transfer

Part-wise shape warping versus whole-object interaction warping. Mug/rack: 23/27 versus 11/27 successful object-pair evaluations One demonstrated end-effector transform with four RGB-D views; initial part prompts and optional resegmentation; cross-category correspondences supplied; pouring task evaluates pre-pour alignment

[Primary source](https://cs.brown.edu/people/gdk/pubs/skilltransfer_partdecomp.pdf), Real Robot evaluation; Table II. Checked 2026-09-21.

## Demo-JEPA

Latent planning versus Demo-DP action head. Familiar real-world tasks favor action head; unseen-task averages favor planning in both domains Table 6 simulation does not show a familiar-task head advantage; small task groups; compare reported means rather than asserting statistical significance

[Primary source](https://arxiv.org/html/2605.20811v1), Sec. 4; Tables 6 and 7. Checked 2026-09-21.

## Zeva

Persistent Interaction Memory present versus removed with Brief Interaction Trace retained. Persistent-memory removal lowers success by 10–20 percentage points across five real tasks 20 randomized episodes per task/configuration; separate evolution plots report cumulative milestones, not per-attempt causal effects

[Primary source](https://arxiv.org/html/2608.30880v1), Sec. IV-D; Table III; Sec. IV-E. Checked 2026-09-21.

## RTCF

Frozen PI-FAST versus aligned low-frequency memory correction. Overall success rises from 86.4% to 88.4%; largest gain on LIBERO-Long Fixed bank; four suites; 2000 episodes/condition; same task-state inventory and seeds; independent restarts are not trajectory-identical; rounded aggregate percentages

[Primary source](https://arxiv.org/html/2608.04527v1), Secs. 4.1–4.2; Table 1. Checked 2026-09-21.

## LMPC

Base PaLM 2-S versus LMPC-Rollouts successor. Test success rises from 39.4% to 66.3%; successful-session mean turns fall from 2.4 to 1.9 Parameter updates between teaching sessions; weights fixed within session; turn mean is conditional on successful sessions

[Primary source](https://arxiv.org/html/2402.11450v1), Table I; Figure 4. Checked 2026-09-21.

## NOLO

Remove versus supply context video. Habitat success: 33.58% ± 0.92% (NOLO-C) versus 43.65% ± 1.09% (NOLO) Same held-out scenes; reported means over three random seeds; simulated evaluation.

[Primary source](https://arxiv.org/html/2408.01384v2), Section 4.5, Table 2. Checked 2026-09-22.

## ReLIC

First versus fifteenth navigation episode. Success increases from 23% to 43%. 8k-step evaluation; same home layout across goals and start positions; simulated ExtObjNav; not the separate 64k configuration.

[Primary source](https://arxiv.org/html/2410.02751v1), Section 4.2. Checked 2026-09-22.

## Added 26 September 2026

- **RAPID**: Mean success 53.2% to 75.9%. Eight nonprehensile simulation tasks, 50 novel scenes per task, three trials; private success criterion; the compared variants share relational program representation Source: https://arxiv.org/pdf/2609.30249 (pp. 6–7, Table II and Sec. VI-B).
- **TraceFlow**: Ordered real packing: 21/50 to 39/50; a subsequent stacking round reaches 47/50. Single real ordered-packing task; the shared-configuration 26-task simulation aggregate is unchanged and counting/occlusion deficits remain. Multi-round stacks are single histories, not independently replicated runs. Source: https://arxiv.org/pdf/2609.20646 (pp. 5–7, Table II, Figure 3, Tables III–IV).
- **FARE**: RoboTwin Easy success: 91.5%, 93.2%, and 91.0%. Frozen base checkpoint; additional search computation differs; removing the trigger searches every step; no uncertainty reported for these rates Source: https://arxiv.org/pdf/2609.18016 (p. 6, Tables I–IV).
