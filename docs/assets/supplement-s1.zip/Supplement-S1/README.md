# Reference census and reported comparisons

The inventory covers all 548 actively cited bibliography entries through 22 October 2026. The four control families contain 351 method and comparison references; the remaining 197 provide data, evaluation, theoretical, survey, or training foundations. `CODEBOOK.md` defines the counting unit and classification rules.

`references.json` and `.csv` contain the full inventory, including citation numbers, titles, dates, primary sources, current manuscript citation passages, and coding reasons. `corpus.json` and `.csv` contain the method subset. The count files preserve their respective denominators. Run `python3 reproduce.py` to check coverage and sums. Figure 9 and Appendix A summarize this corpus.

`reported-comparisons.json` and `.csv` accompany Table 16. They record fourteen representative published comparisons, their changed factors, findings, evaluation conditions, and source locations. `REPORTED-COMPARISONS.md` explains selection and interpretation. These records complement the census and are not included as additional references.

Mechanism, parameter updates, storage, and modality are independent attributes. A four-family assignment does not by itself establish fixed-weight ICL. Counts represent review coverage rather than an exhaustive census of the field.
